Page({
    /**
       * 页面的初始数据
       */
      data: {
        isPopping: false,//是否已经弹出
        animPlus: {},//旋转动画
        animCollect: {},//item位移,透明度
        animTranspond: {},//item位移,透明度
        animInput: {},//item位移,透明度
        left: 0,
        top: 0,
        isIos: true // 小程序运行的环境是否是ios，默认为true
      },
        /**
       * 生命周期函数--监听页面加载
       */
      onLoad: function (options) {
        wx.getSystemInfo({
          success: (res) => {
            if (res.platform == "android") {
            // 判断小程序运行的环境
              this.setData({
                isIos: false
              })
            }
          }
        })
      },
      /**
      * 安卓机和ios兼容问题
      */
       handleSetMoveViewPos: function (e) {
         console.log('handleSetMoveViewPos,e',this.data.isIos);
        // 在ios下永远都不会走这个方案，以免引起无用的计算
        if (!this.data.isIos) {
          const RADIUS = 30 // 悬浮窗半径
    
          const touchPosX = e.touches[0].clientX
          const touchPosY = e.touches[0].clientY
    
          const moveViewCenterPosX = this.data.left + RADIUS
          const moveViewCenterPosY = this.data.top + RADIUS
    
          // 确保手指在悬浮窗上才可以移动
          if (Math.abs(moveViewCenterPosX - touchPosX) < RADIUS && Math.abs(moveViewCenterPosY - touchPosY) < RADIUS) {
            if (touchPosX > 0 && touchPosY > 0) {
              this.setData({
                left: touchPosX - RADIUS,
                top: touchPosY - RADIUS
              })
            } else {
              this.setData({
                left: 0, // 默认显示位置 left距离
                top: 0  // 默认显示位置 top距离
              })
            }
          }
        }
      },
      /**
      * 拖拽移动
      */
       handleTouchMove: function (e) {
         console.log('handleTouchMove---->',e);
        const RADIUS = 30 // 悬浮窗半径
    
        const touchPosX = e.touches[0].clientX
        const touchPosY = e.touches[0].clientY
    
        if (touchPosX > 0 && touchPosY > 0) {
          this.setData({
            left: touchPosX - RADIUS,
            top: touchPosY - RADIUS
          })
        } else {
          this.setData({
            left: 0, //默认显示位置 left距离
            top: 0  //默认显示位置 top距离
          })
        }
      },
      
      
      //点击弹出
  plus: function () {
    if (this.data.isPopping) {
        //缩回动画
        this.popp();
        this.setData({
            isPopping: false
        })
    } else if (!this.data.isPopping) {
        //弹出动画
        this.takeback();
        this.setData({
            isPopping: true
        })
    }
},
input: function () {
    console.log("input")
},
transpond: function () {
    console.log("transpond")
},
collect: function () {
    console.log("collect")
},

//弹出动画
popp: function () {
    //plus顺时针旋转
    var animationPlus = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationcollect = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationTranspond = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationInput = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(0).step();
    animationcollect.translate(-100, -100).rotateZ(0).opacity(1).step();
    animationTranspond.translate(-140, 0).rotateZ(0).opacity(1).step();
    animationInput.translate(-100, 100).rotateZ(0).opacity(1).step();
    this.setData({
        animPlus: animationPlus.export(),
        animCollect: animationcollect.export(),
        animTranspond: animationTranspond.export(),
        animInput: animationInput.export(),
    })
},
//收回动画
takeback: function () {
    //plus逆时针旋转
    var animationPlus = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationcollect = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationTranspond = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    var animationInput = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease-out'
    })
    animationPlus.rotateZ(0).step();
    animationcollect.translate(0, 0).rotateZ(0).opacity(0).step();
    animationTranspond.translate(0, 0).rotateZ(0).opacity(0).step();
    animationInput.translate(0, 0).rotateZ(0).opacity(0).step();
    this.setData({
        animPlus: animationPlus.export(),
        animCollect: animationcollect.export(),
        animTranspond: animationTranspond.export(),
        animInput: animationInput.export(),
    })
},

    })
    